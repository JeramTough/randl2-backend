package com.jeramtough.randl2.userapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Randl2AdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(Randl2AdminApplication.class, args);
	}

}
