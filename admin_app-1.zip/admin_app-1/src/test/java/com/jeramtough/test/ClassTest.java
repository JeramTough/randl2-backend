package com.jeramtough.test;

import org.junit.Test;

/**
 * <pre>
 * Created on 2020/9/11 13:50
 * by @author WeiBoWen
 * </pre>
 */
public class ClassTest {

    @Test
    public void test1(){

        System.out.println();
    }

}
