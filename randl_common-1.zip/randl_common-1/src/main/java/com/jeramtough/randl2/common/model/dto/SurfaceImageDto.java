package com.jeramtough.randl2.common.model.dto;

/**
 * <pre>
 * Created on 2020/2/9 12:08
 * by @author JeramTough
 * </pre>
 */
public class SurfaceImageDto {

    private Long fid;

    private String surfaceImage;

    public Long getFid() {
        return fid;
    }

    public void setFid(Long fid) {
        this.fid = fid;
    }

    public String getSurfaceImage() {
        return surfaceImage;
    }

    public void setSurfaceImage(String surfaceImage) {
        this.surfaceImage = surfaceImage;
    }
}
