package com.jeramtough.randl2.common.constant;

/**
 * <pre>
 * Created on 2020-08-06 16:07
 * by @author JeramTough
 * </pre>
 */
public class SysModuleConstant {


}
