package com.jeramtough.randl2.common.util;

/**
 * <pre>
 * Created on 2020/1/30 11:25
 * by @author JeramTough
 * </pre>
 */
public class WebUtil {

}
